%% Setup
clear all
close all
clc

len = 10000;
f   = logspace(1,8,len);
w   = 2*pi*f;
s   = 1j*w;
Vm  = 5;
H   = 1/4;


%%% Gvd - Control-to-Output Transfer

% Gvd Parameters (THESE ARE GIVEN FROM YOUR TOPOLOGY, NOT CHOSEN)
Go = 49.7;
Q  = 5.8;
wo = 2*pi*76e3;

Gvd = (Go)./(1+(s./(Q*wo))+(s./wo).^2);

% % Plot Gvd
% figure
% semilogx(f,20*log10(abs(Gvd)))
% waitforbuttonpress()


%%% PD Compensation - Improvement of Phase Margin

% PD Compensator Parameters
fc = 200e3;
theta = 60*pi/180;
wz = 2*pi*fc*sqrt((1-sin(theta))/(1+sin(theta)));
wp = 2*pi*fc*sqrt((1+sin(theta))/(1-sin(theta)));
% wz = 50e3;
% wp = 400e3;
Gco = sqrt(wz/wp);

GcPD = Gco*(1+s/wz)./(1+s/wp);

% Plot w/ PD and Vm
figure
semilogx(f,20*log10(abs(Gvd.*GcPD.*H./Vm)))
waitforbuttonpress()


%% PI Compensation - Improvement of Gain (Especially Low-Frequency)

% PI Compensator Parameters
Gcinf = 2;
wl = 100e3;

GcPI = Gcinf*(1+wl./s);


%%% Overall Transfer Function

% Product of Terms forms T
T = H.*(Gvd.*GcPD.*GcPI)./Vm;
TdB = 20*log10(abs(T));
Tphz = atan2(imag(T),real(T));

figure
semilogx(f,TdB,'g');
%figure
hold on
semilogx(f,Tphz*180/pi,'r');


%% Compensator Design as OpAmp

% Pick R2; Rest Follows...
R2 = 50e3;

R1 = R2/Gco;
C2 = 1/(R1*wl);
C1 = 1/(R1*wz);
R3 = 1/(wp*C1);

format shortEng
fprintf("R1= %d\nR2= %d\nR3= %d (Can Be Made From Divider)\nC1= %d\nC2= %d\n\n",R1,R2,R3,C1,C2)


